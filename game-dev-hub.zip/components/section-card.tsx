import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, type LucideIcon } from "lucide-react"

interface SectionCardProps {
  title: string
  description: string
  icon: LucideIcon
  items: Array<{
    title: string
    description: string
    date?: string
    category?: string
  }>
  viewAllText: string
}

export function SectionCard({ title, description, icon: Icon, items, viewAllText }: SectionCardProps) {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
            <Icon className="w-5 h-5 text-primary" />
          </div>
          <div>
            <CardTitle className="text-2xl">{title}</CardTitle>
            <CardDescription className="text-muted-foreground">{description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {items.map((item, index) => (
            <div key={index} className="p-4 bg-muted/50 rounded-lg hover:bg-muted/70 transition-colors cursor-pointer">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-semibold text-foreground">{item.title}</h4>
                {item.date && <span className="text-sm text-muted-foreground">{item.date}</span>}
              </div>
              <p className="text-sm text-muted-foreground mb-2">{item.description}</p>
              {item.category && (
                <span className="inline-block px-2 py-1 bg-primary/20 text-primary text-xs rounded-full">
                  {item.category}
                </span>
              )}
            </div>
          ))}
        </div>
        <Button variant="outline" className="w-full mt-6 bg-transparent">
          {viewAllText}
          <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </CardContent>
    </Card>
  )
}
