import { Navigation } from "@/components/navigation"
import { Code, Search, Play, Clock, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const codexCourses = [
  {
    title: "Unity Fundamentals Course",
    description:
      "My comprehensive course covering Unity basics, perfect for beginners starting their game dev journey. Learn the interface, scripting basics, and create your first game.",
    category: "Course",
    duration: "12 hours",
    lessons: 24,
    students: 1250,
    level: "Beginner",
    price: "$49",
  },
  {
    title: "C# for Game Developers",
    description:
      "Complete programming course focused on C# concepts specifically for game development applications. From variables to advanced OOP concepts.",
    category: "Course",
    duration: "16 hours",
    lessons: 32,
    students: 890,
    level: "Beginner",
    price: "$59",
  },
  {
    title: "Game Design Principles Masterclass",
    description:
      "In-depth course exploring core game design concepts and how to apply them to your projects. Learn about player psychology, mechanics, and balancing.",
    category: "Course",
    duration: "10 hours",
    lessons: 20,
    students: 650,
    level: "Intermediate",
    price: "$79",
  },
  {
    title: "Advanced Unity Techniques",
    description:
      "Take your Unity skills to the next level with advanced scripting, optimization techniques, and professional development practices.",
    category: "Course",
    duration: "20 hours",
    lessons: 40,
    students: 420,
    level: "Advanced",
    price: "$99",
  },
  {
    title: "Mobile Game Development",
    description:
      "Learn to create and optimize games for mobile platforms. Covers touch controls, performance optimization, and monetization strategies.",
    category: "Course",
    duration: "14 hours",
    lessons: 28,
    students: 780,
    level: "Intermediate",
    price: "$69",
  },
  {
    title: "Indie Game Marketing",
    description:
      "Essential marketing strategies for indie developers. Learn how to build an audience, create compelling trailers, and launch successfully.",
    category: "Course",
    duration: "8 hours",
    lessons: 16,
    students: 340,
    level: "Beginner",
    price: "$39",
  },
]

const levels = ["All", "Beginner", "Intermediate", "Advanced"]

export default function CodexPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <Code className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Codex</h1>
              <p className="text-muted-foreground">My comprehensive development courses and learning materials</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 mb-8">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="Search courses..." className="pl-10" />
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {levels.map((level) => (
              <Button key={level} variant={level === "All" ? "default" : "outline"} size="sm" className="text-xs">
                {level}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {codexCourses.map((course, index) => (
            <article
              key={index}
              className="group cursor-pointer bg-card border border-border rounded-lg overflow-hidden hover:border-primary/50 transition-colors"
            >
              <img
                src={`/abstract-geometric-shapes.png?height=200&width=300&query=${course.title}`}
                alt={course.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="inline-block px-2 py-1 bg-primary/10 text-primary text-xs rounded-md">
                    {course.level}
                  </span>
                  <span className="text-lg font-bold text-primary">{course.price}</span>
                </div>
                <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                  {course.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-3">{course.description}</p>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    <span>{course.duration}</span>
                    <span>•</span>
                    <Play className="w-3 h-3" />
                    <span>{course.lessons} lessons</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Users className="w-3 h-3" />
                    <span>{course.students.toLocaleString()} students</span>
                  </div>
                </div>
                <Button className="w-full">Enroll Now</Button>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  )
}
