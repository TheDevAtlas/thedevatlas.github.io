import { Navigation } from "@/components/navigation"
import { BookOpen, Calendar, User, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const workshopPosts = [
  {
    title: "Building My Indie RPG: Combat System Deep Dive",
    description:
      "A detailed breakdown of how I designed and implemented the turn-based combat system for my current project. I'll walk through the decision-making process, code architecture, and lessons learned.",
    date: "Dec 15",
    category: "Project Update",
    author: "Lucas N.",
    image: "/pixel-art-rpg-combat-scene.jpg",
    readTime: "8 min read",
  },
  {
    title: "Lessons from My First Game Jam",
    description:
      "What I learned during my 48-hour game jam experience and how it changed my development approach. From scope management to rapid prototyping techniques.",
    date: "Dec 12",
    category: "Experience",
    author: "Lucas N.",
    image: "/game-jam-workspace-setup.jpg",
    readTime: "6 min read",
  },
  {
    title: "Prototyping My Puzzle Platformer",
    description:
      "Early development insights and challenges I'm facing while creating my latest puzzle game. Exploring mechanics, level design, and player feedback integration.",
    date: "Dec 10",
    category: "Prototype",
    author: "Lucas N.",
    image: "/puzzle-platformer-level-design.jpg",
    readTime: "10 min read",
  },
  {
    title: "Implementing Procedural Generation",
    description:
      "How I built a procedural dungeon generator for my roguelike project using cellular automata. Complete with code examples and performance considerations.",
    date: "Dec 8",
    category: "Technical",
    author: "Lucas N.",
    image: "/procedural-dungeon-generation.jpg",
    readTime: "12 min read",
  },
  {
    title: "Art Pipeline for Solo Developers",
    description:
      "My workflow for creating consistent pixel art assets when working alone on indie projects. Tools, techniques, and time-saving strategies.",
    date: "Dec 5",
    category: "Art & Design",
    author: "Lucas N.",
    image: "/pixel-art-character-sprites.jpg",
    readTime: "7 min read",
  },
  {
    title: "Sound Design on a Budget",
    description:
      "Creating immersive audio experiences using free tools and creative recording techniques. From ambient soundscapes to dynamic music systems.",
    date: "Dec 3",
    category: "Audio",
    author: "Lucas N.",
    image: "/audio-waveform-editing.jpg",
    readTime: "9 min read",
  },
]

const categories = ["All", "Project Update", "Experience", "Prototype", "Technical", "Art & Design", "Audio"]

export default function WorkshopPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Workshop</h1>
              <p className="text-muted-foreground">My development journey, project updates, and lessons learned</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 mb-8">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="Search workshop posts..." className="pl-10" />
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {categories.map((category) => (
              <Button key={category} variant={category === "All" ? "default" : "outline"} size="sm" className="text-xs">
                {category}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {workshopPosts.map((post, index) => (
            <article
              key={index}
              className="group cursor-pointer bg-card border border-border rounded-lg overflow-hidden hover:border-primary/50 transition-colors"
            >
              <img src={post.image || "/placeholder.svg"} alt={post.title} className="w-full h-48 object-cover" />
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="inline-block px-2 py-1 bg-primary/10 text-primary text-xs rounded-md">
                    {post.category}
                  </span>
                  <span className="text-xs text-muted-foreground">{post.readTime}</span>
                </div>
                <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors line-clamp-2">
                  {post.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-3">{post.description}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <User className="w-3 h-3" />
                  <span>{post.author}</span>
                  <span>•</span>
                  <Calendar className="w-3 h-3" />
                  <span>{post.date}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  )
}
