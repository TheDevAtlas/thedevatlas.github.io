import { Navigation } from "@/components/navigation"
import { Database, Search, ExternalLink, Tag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const cacheResources = [
  {
    title: "Kenney.nl Asset Packs",
    description:
      "High-quality free game assets including sprites, sounds, and 3D models for indie developers. Consistently updated with new content and themes.",
    category: "External Assets",
    url: "https://kenney.nl",
    tags: ["Free", "Sprites", "3D Models", "Audio"],
  },
  {
    title: "OpenGameArt Community",
    description:
      "Massive collection of free art assets contributed by artists worldwide for game development. Browse by category, license, or art style.",
    category: "External Site",
    url: "https://opengameart.org",
    tags: ["Community", "Art", "Free", "Open Source"],
  },
  {
    title: "Brackeys Unity Tutorials",
    description:
      "Comprehensive video tutorial series covering Unity fundamentals and advanced techniques. Perfect for beginners and intermediate developers.",
    category: "External Tutorial",
    url: "https://youtube.com/brackeys",
    tags: ["Unity", "Video", "Beginner", "Free"],
  },
  {
    title: "itch.io Game Assets",
    description:
      "Marketplace for indie game assets including art, audio, and tools. Both free and premium options available from independent creators.",
    category: "External Assets",
    url: "https://itch.io/game-assets",
    tags: ["Marketplace", "Indie", "Premium", "Tools"],
  },
  {
    title: "Freesound Audio Library",
    description:
      "Collaborative database of Creative Commons licensed sounds. Perfect for finding sound effects and ambient audio for your games.",
    category: "External Assets",
    url: "https://freesound.org",
    tags: ["Audio", "SFX", "Creative Commons", "Free"],
  },
  {
    title: "Game Development Subreddit",
    description:
      "Active community of game developers sharing resources, feedback, and industry insights. Great for networking and learning.",
    category: "External Site",
    url: "https://reddit.com/r/gamedev",
    tags: ["Community", "Discussion", "Feedback", "Networking"],
  },
]

const categories = ["All", "External Assets", "External Site", "External Tutorial"]

export default function CachePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <Database className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Cache</h1>
              <p className="text-muted-foreground">
                Curated external resources, tools, and assets for game development
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 mb-8">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="Search resources..." className="pl-10" />
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {categories.map((category) => (
              <Button key={category} variant={category === "All" ? "default" : "outline"} size="sm" className="text-xs">
                {category}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cacheResources.map((resource, index) => (
            <article
              key={index}
              className="group cursor-pointer bg-card border border-border rounded-lg overflow-hidden hover:border-primary/50 transition-colors"
            >
              <img
                src={`/abstract-geometric-shapes.png?height=200&width=300&query=${resource.title}`}
                alt={resource.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="inline-block px-2 py-1 bg-primary/10 text-primary text-xs rounded-md">
                    {resource.category}
                  </span>
                  <ExternalLink className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                  {resource.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-3">{resource.description}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {resource.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="inline-flex items-center gap-1 px-2 py-1 bg-background border border-border rounded text-xs"
                    >
                      <Tag className="w-2 h-2" />
                      {tag}
                    </span>
                  ))}
                </div>
                <Button variant="outline" size="sm" className="w-full bg-transparent">
                  Visit Resource
                </Button>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  )
}
